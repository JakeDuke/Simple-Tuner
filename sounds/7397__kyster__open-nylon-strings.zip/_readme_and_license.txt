Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Kyster ( https://freesound.org/people/Kyster/ )

You can find this pack online at: https://freesound.org/people/Kyster/packs/7397/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 117679__Kyster__e_open_string.wav
    * url: https://freesound.org/s/117679/
    * license: Attribution
  * 117678__Kyster__G_open_string.wav
    * url: https://freesound.org/s/117678/
    * license: Attribution
  * 117677__Kyster__E_open_string.wav
    * url: https://freesound.org/s/117677/
    * license: Attribution
  * 117676__Kyster__D_open_string.wav
    * url: https://freesound.org/s/117676/
    * license: Attribution
  * 117675__Kyster__D_low_open_string.wav
    * url: https://freesound.org/s/117675/
    * license: Attribution
  * 117674__Kyster__B_open_string.wav
    * url: https://freesound.org/s/117674/
    * license: Attribution
  * 117673__Kyster__A_open_string.wav
    * url: https://freesound.org/s/117673/
    * license: Attribution


